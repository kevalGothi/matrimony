<?php
    session_start();
    include "db/conn.php";
    
    // For development, show errors. You can remove this in production.
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
?>
<?php 
    include "inc/header.php";
    include "inc/bodystart.php";
    include "inc/navbar.php";
?>
<?php
    // --- AUTHENTICATION ---
    if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
        $userN = $_SESSION['username'];
        $psw = $_SESSION['password'];

        $user_query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE user_phone = '$userN' AND user_pass = '$psw'");
        
        if ($user_query && mysqli_num_rows($user_query) > 0) {
            $fe = mysqli_fetch_assoc($user_query);
            $loggedInUserID = $fe['user_id'];

            // --- PART 1: HANDLE SENDING A NEW INTEREST ---
            if (isset($_GET['send_interest'])) {
                $receiverID = (int)$_GET['send_interest'];
                $senderID = $loggedInUserID;

                // Check if an interest request already exists between these two users
                $check_sql = "SELECT chat_id FROM tbl_chat WHERE 
                              ((chat_senderID = $senderID AND chat_receiverID = $receiverID) OR (chat_senderID = $receiverID AND chat_receiverID = $senderID))
                              AND interest_status IN (0, 1)";
                $check_result = mysqli_query($conn, $check_sql);

                if (mysqli_num_rows($check_result) == 0) {
                    // No pending or accepted interest exists, so insert a new one.
                    $interest_message = "I am interested in your profile."; // Default message
                    $insert_sql = "INSERT INTO tbl_chat (chat_senderID, chat_receiverID, chat_message, interest_status) VALUES ('$senderID', '$receiverID', '$interest_message', '0')";
                    
                    if(mysqli_query($conn, $insert_sql)) {
                        echo "<script>alert('Interest sent successfully!'); window.location.href='user-interests.php';</script>";
                    } else {
                        echo "<script>alert('Error sending interest.'); window.location.href='see-other-profile.php';</script>";
                    }
                } else {
                    // An interest already exists
                    echo "<script>alert('You have already sent an interest to this person, or they have sent one to you.'); window.location.href='see-other-profile.php';</script>";
                }
                exit(); // Stop the script after handling the action
            }

            // --- PART 2: FETCH AND DISPLAY INTERESTS RECEIVED ---
            $base_query = "SELECT tbl_chat.*, tbl_user.* 
                           FROM tbl_chat
                           JOIN tbl_user ON tbl_chat.chat_senderID = tbl_user.user_id
                           WHERE tbl_chat.chat_receiverID = '$loggedInUserID'
                           AND tbl_chat.interest_status != 9"; // Fetch only interests, not regular chats

            // 1. New/Pending Requests (status = 0)
            $new_requests_result = mysqli_query($conn, $base_query . " AND tbl_chat.interest_status = 0 ORDER BY tbl_chat.chat_date DESC");
            $new_requests_count = $new_requests_result ? mysqli_num_rows($new_requests_result) : 0;

            // 2. Accepted Requests (status = 1)
            $accepted_requests_result = mysqli_query($conn, $base_query . " AND tbl_chat.interest_status = 1 ORDER BY tbl_chat.chat_date DESC");

            // 3. Denied Requests (status = 2)
            $denied_requests_result = mysqli_query($conn, $base_query . " AND tbl_chat.interest_status = 2 ORDER BY tbl_chat.chat_date DESC");

?>
        <!-- USER DASHBOARD SECTION -->
        <section>
            <div class="db">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-lg-3">
                            <div class="db-nav">
                                <div class="db-nav-pro">
                                    <img src="upload/<?php echo !empty($fe['user_img']) ? $fe['user_img'] : 'default-profile.png'; ?>" class="img-fluid" alt="User Profile Image">
                                </div>
                                <div class="db-nav-pro"><img src="images/profiles/12.jpg" class="img-fluid" alt=""></div>
                            <div class="db-nav-list">
                                <ul>
                                        <li>
                                            <a href="user-dashboard.php">
                                                <i class="fa fa-tachometer" aria-hidden="true"></i>Dashboard
                                            </a>
                                        </li>
                                        <li>
                                            <a href="user-profile.php">
                                                <i class="fa fa-male" aria-hidden="true"></i>Profile
                                            </a>
                                        </li>
                                        <li>
                                            <a href="see-other-profile.php" class="">
                                                <i class="fa fa-male" aria-hidden="true"></i>See Others Profile
                                            </a>
                                        </li>
                                        <li><a href="user-profile-edit.php"><i class="fa fa-male" aria-hidden="true"></i>Edit Profile</a></li>
                                        <li>
                                            <a href="user-interests.php" class="act">
                                                <i class="fa fa-handshake-o" aria-hidden="true"></i>Interests
                                            </a>
                                        </li>
                                        <li>
                                            <a href="user-chat.php">
                                                <i class="fa fa-commenting-o" aria-hidden="true"></i>Chat list
                                            </a>
                                        </li>
                                        <li>
                                            <a href="plans.php">
                                                <i class="fa fa-money" aria-hidden="true"></i>Plan
                                            </a>
                                        </li>
                                        <li>
                                            <a href="user-setting.php">
                                                <i class="fa fa-cog" aria-hidden="true"></i>Setting
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-sign-out" aria-hidden="true"></i>Log out
                                            </a>
                                        </li>
                                    </ul>
                            </div>
                            </div>
                        </div>
                                            <div class="col-md-8 col-lg-9">
                        <div class="row">
                            <div class="col-md-12 db-sec-com">
                                <h2 class="db-tit">Interest request</h2>
                                <div class="db-pro-stat">
                                    <div class="dropdown">
                                        <button type="button" class="btn btn-outline-secondary" data-bs-toggle="dropdown">
                                            <i class="fa fa-ellipsis-h" aria-hidden="true"></i>
                                        </button>
                                        <ul class="dropdown-menu">
                                          <li><a class="dropdown-item" href="#">Edid profile</a></li>
                                          <li><a class="dropdown-item" href="#">View profile</a></li>
                                          <li><a class="dropdown-item" href="#">Plan change</a></li>
                                          <li><a class="dropdown-item" href="#">Download invoice now</a></li>
                                        </ul>
                                    </div>
                                    <div class="db-inte-main">
                                       
                                          <ul class="nav nav-tabs" role="tablist">
                                            <li class="nav-item">
                                              <a class="nav-link active" data-bs-toggle="tab" href="#home">New requests</a>
                                            </li>
                                            <li class="nav-item">
                                              <a class="nav-link" data-bs-toggle="tab" href="#menu1">Accept request</a>
                                            </li>
                                            <li class="nav-item">
                                              <a class="nav-link" data-bs-toggle="tab" href="#menu2">Denay request</a>
                                            </li>
                                          </ul>
                                          <!-- Tab panes -->
  <!-- Tab panes -->
  <div class="tab-content">
    <div id="home" class="container tab-pane active"><br>
      <div class="db-inte-prof-list">
            <ul>
                <li>
                    <div class="db-int-pro-1"> <img src="images/profiles/men1.jpg" alt=""> <span class="badge bg-primary user-pla-pat">Platinum user</span></div>
                    <div class="db-int-pro-2">
                        <h5>John Smith</h5> 
                        <ol class="poi">
                            <li>City: <strong>Illunois</strong></li>
                            <li>Age: <strong>21</strong></li>
                            <li>Height: <strong>5.7</strong></li>
                            <li>Job: <strong>Working</strong></li>
                        </ol>
                        <ol class="poi poi-date">
                            <li>Request on: 10:30 AM, 18 August 2024</li>
                        </ol>
                        <a href="profile-details.html" class="cta-5" target="_blank">View full profile</a>
                    </div>
                    <div class="db-int-pro-3">
                        <button type="button" class="btn btn-success btn-sm">Accept</button>
                        <button type="button" class="btn btn-outline-danger btn-sm">Denay</button>
                    </div>
                </li>
                <li>
                    <div class="db-int-pro-1"> <img src="images/profiles/men2.jpg" alt=""> <span class="badge bg-primary user-pla-gold">Gold user</span></div>
                    <div class="db-int-pro-2">
                        <h5>John Smith</h5> 
                        <ol class="poi">
                            <li>City: <strong>Illunois</strong></li>
                            <li>Age: <strong>21</strong></li>
                            <li>Height: <strong>5.7</strong></li>
                            <li>Job: <strong>Working</strong></li>
                        </ol>
                        <ol class="poi poi-date">
                            <li>Request on: 10:30 AM, 18 August 2024</li>
                        </ol>
                        <a href="profile-details.html" class="cta-5" target="_blank">View full profile</a>
                    </div>
                    <div class="db-int-pro-3">
                        <button type="button" class="btn btn-success btn-sm">Accept</button>
                        <button type="button" class="btn btn-outline-danger btn-sm">Denay</button>
                    </div>
                </li>
                <li>
                    <div class="db-int-pro-1"> <img src="images/profiles/men3.jpg" alt=""> <span class="badge bg-primary user-pla-free">Free user</span></div>
                    <div class="db-int-pro-2">
                        <h5>John Smith</h5> 
                        <ol class="poi">
                            <li>City: <strong>Illunois</strong></li>
                            <li>Age: <strong>21</strong></li>
                            <li>Height: <strong>5.7</strong></li>
                            <li>Job: <strong>Working</strong></li>
                        </ol>
                        <ol class="poi poi-date">
                            <li>Request on: 10:30 AM, 18 August 2024</li>
                        </ol>
                        <a href="profile-details.html" class="cta-5" target="_blank">View full profile</a>
                    </div>
                    <div class="db-int-pro-3">
                        <button type="button" class="btn btn-success btn-sm">Accept</button>
                        <button type="button" class="btn btn-outline-danger btn-sm">Denay</button>
                    </div>
                </li>
                <li>
                    <div class="db-int-pro-1"> <img src="images/profiles/men4.jpg" alt=""> </div>
                    <div class="db-int-pro-2">
                        <h5>John Smith</h5> 
                        <ol class="poi">
                            <li>City: <strong>Illunois</strong></li>
                            <li>Age: <strong>21</strong></li>
                            <li>Height: <strong>5.7</strong></li>
                            <li>Job: <strong>Working</strong></li>
                        </ol>
                        <ol class="poi poi-date">
                            <li>Request on: 10:30 AM, 18 August 2024</li>
                        </ol>
                        <a href="profile-details.html" class="cta-5" target="_blank">View full profile</a>
                    </div>
                    <div class="db-int-pro-3">
                        <button type="button" class="btn btn-success btn-sm">Accept</button>
                        <button type="button" class="btn btn-outline-danger btn-sm">Denay</button>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div id="menu1" class="container tab-pane fade"><br>
        <div class="db-inte-prof-list">
            <ul>
                <li>
                    <div class="db-int-pro-1"> <img src="images/profiles/men5.jpg" alt=""> </div>
                    <div class="db-int-pro-2">
                        <h5>John Smith</h5> 
                        <ol class="poi">
                            <li>City: <strong>Illunois</strong></li>
                            <li>Age: <strong>21</strong></li>
                            <li>Height: <strong>5.7</strong></li>
                            <li>Job: <strong>Working</strong></li>
                        </ol>
                        <ol class="poi poi-date">
                            <li>Request on: 10:30 AM, 18 August 2024</li>
                            <li>Accept on: 3:000 PM, 21 August 2024</li>
                        </ol>
                        <a href="profile-details.html" class="cta-5" target="_blank">View full profile</a>
                    </div>
                    <div class="db-int-pro-3">
                        <button type="button" class="btn btn-outline-danger btn-sm">Denay</button>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div id="menu2" class="container tab-pane fade"><br>
        <div class="db-inte-prof-list">
            <ul>
                <li>
                    <div class="db-int-pro-1"> <img src="images/profiles/men1.jpg" alt=""> </div>
                    <div class="db-int-pro-2">
                        <h5>John Smith</h5> 
                        <ol class="poi">
                            <li>City: <strong>Illunois</strong></li>
                            <li>Age: <strong>21</strong></li>
                            <li>Height: <strong>5.7</strong></li>
                            <li>Job: <strong>Working</strong></li>
                        </ol>
                        <ol class="poi poi-date">
                            <li>Request on: 10:30 AM, 18 August 2024</li>
                            <li>Denay on: 3:000 PM, 21 August 2024</li>
                        </ol>
                        <a href="profile-details.html" class="cta-5" target="_blank">View full profile</a>
                    </div>
                    <div class="db-int-pro-3">
                        <button type="button" class="btn btn-success btn-sm">Accept</button>
                    </div>
                </li>
            </ul>
        </div>
    </div>
  </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </section>
<?php
        } else {
            echo "<div class='container p-5 text-center'><h2>Session Error</h2><p>Please log in again.</p><a href='logout.php' class='btn btn-primary'>Login</a></div>";
        }
    } else {
        echo "<script>alert('Please login to continue.'); window.location.href='login.html';</script>";
    }
?>
<?php 
    // Assuming you have a standard footer include
    // include "inc/footer.php"; 
?>