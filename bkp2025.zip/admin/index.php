<?php
session_start();
include "../db/conn.php"; // This path is correct for a file inside the /admin/ folder

// --- Part 1: Authentication and Action Processing ---

// Check if admin session exists
if (!isset($_SESSION['username']) || !isset($_SESSION['pass'])) {
    echo "<script>window.location.href='login/';</script>";
    exit();
}

$admin_email = $_SESSION['username'];
$admin_pass = $_SESSION['pass'];

// Verify admin credentials against the database
$adminsql = mysqli_query($conn, "select * from tbl_admin where ad_email = '$admin_email' and ad_pass = '$admin_pass'");
if (mysqli_num_rows($adminsql) == 0) {
    // If credentials are no longer valid, destroy session and redirect
    session_destroy();
    echo "<script>alert('Your session has expired or is invalid. Please log in again.'); window.location.href='login/';</script>";
    exit();
}
$adminfetch = mysqli_fetch_array($adminsql);

// Process Approve/Reject/Delete actions if a form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id_action'])) {
    $user_id = (int)$_POST['user_id_action'];
    
    if (isset($_POST['approve'])) {
        $new_status = 1; // Approve
        $stmt = $conn->prepare("UPDATE tbl_user SET user_status = ? WHERE user_id = ?");
        $stmt->bind_param("ii", $new_status, $user_id);
        $stmt->execute();
    } elseif (isset($_POST['reject'])) {
        $new_status = 2; // Reject (a "soft delete", keeps the record)
        $stmt = $conn->prepare("UPDATE tbl_user SET user_status = ? WHERE user_id = ?");
        $stmt->bind_param("ii", $new_status, $user_id);
        $stmt->execute();
    } elseif (isset($_POST['delete'])) {
        // PERMANENTLY DELETE USER - Use with caution
        $stmt = $conn->prepare("DELETE FROM tbl_user WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
    }
    
    // Redirect back to the dashboard to see the changes
    header("Location: index.php?update=success");
    exit();
}

// --- Part 2: HTML Structure and Page Content ---
include "inc/header.php"; 
?>
<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">
  <div class="layout-container">
    <?php include "inc/side_bar.php"; ?>
    <!-- Layout container -->
    <div class="layout-page">
      <?php include "inc/top_bar.php"; ?>
      <!-- Content wrapper -->
      <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
            <?php
            // Check if we are viewing a single user or the main dashboard
            if (isset($_GET['view_id'])) {
                // --- DETAIL VIEW MODE ---
                $user_id_to_view = (int)$_GET['view_id'];
                $stmt = $conn->prepare("SELECT * FROM tbl_user WHERE user_id = ?");
                $stmt->bind_param("i", $user_id_to_view);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();

                if ($user) {
            ?>
                <a href="index.php" class="btn btn-secondary mb-3">« Back to Dashboard</a>
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Full Details for <?php echo htmlspecialchars($user['user_name']); ?></h5>
                        <div>
                            Current Status: 
                            <?php 
                                if ($user['user_status'] == 1) echo '<span class="badge bg-label-success">Approved</span>';
                                elseif ($user['user_status'] == 2) echo '<span class="badge bg-label-danger">Rejected</span>';
                                else echo '<span class="badge bg-label-warning">Pending</span>';
                            ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 text-center">
                                <h6>Profile Photo</h6>
                                <?php if (!empty($user['user_img'])): ?>
                                    <img src="../upload/<?php echo htmlspecialchars($user['user_img']); ?>" alt="Profile Photo" class="img-fluid rounded mb-3" style="max-height: 300px;">
                                <?php else: ?>
                                    <p class="text-muted">No photo uploaded.</p>
                                <?php endif; ?>

                                <!-- Admin Action Buttons -->
                                <div class="mt-4">
                                    <form method="POST" action="index.php" onsubmit="return confirm('Are you sure you want to proceed?');">
                                        <input type="hidden" name="user_id_action" value="<?php echo $user['user_id']; ?>">
                                        <?php if ($user['user_status'] != 1): ?>
                                            <button type="submit" name="approve" class="btn btn-success w-100 mb-2">Approve Profile</button>
                                        <?php endif; ?>
                                        <?php if ($user['user_status'] != 2): ?>
                                            <button type="submit" name="reject" class="btn btn-warning w-100 mb-2">Reject Profile</button>
                                        <?php endif; ?>
                                        <button type="submit" name="delete" class="btn btn-danger w-100" onclick="return confirm('WARNING: This will permanently delete the user. Are you absolutely sure?');">Delete User</button>
                                    </form>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <h6>All User Information</h6>
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <?php foreach ($user as $key => $value): ?>
                                        <tr>
                                            <th style="width: 200px;"><?php echo ucwords(str_replace('_', ' ', $key)); ?></th>
                                            <td><?php echo htmlspecialchars($value); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
                } else {
                    echo "<div class='alert alert-danger'>User not found.</div>";
                }

            } else {
                // --- DASHBOARD MODE (DEFAULT) ---
            ?>
                <!-- Pending Users List -->
                <div class="card mb-4">
                    <div class="card-header"><h5 class="card-title">Users Pending Approval</h5></div>
                    <div class="card-datatable table-responsive">
                        <table class="table border-top">
                            <thead><tr><th>ID</th><th>Client Name</th><th>Number</th><th>Registered On</th><th>Actions</th></tr></thead>
                            <tbody>
                                <?php 
                                $desql_pending = mysqli_query($conn, "SELECT * FROM tbl_user WHERE user_status = 0 AND user_payment_status = 1 ORDER BY user_id DESC");
                                if (mysqli_num_rows($desql_pending) > 0) {
                                foreach($desql_pending as $data){ ?>
                                <tr>
                                    <td><?php echo $data['user_id']; ?></td>
                                    <td><?php echo htmlspecialchars($data['user_name']); ?></td>
                                    <td><?php echo htmlspecialchars($data['user_phone']); ?></td>
                                    <td><?php echo date('d-m-Y', strtotime($data['user_create_date'])); ?></td>
                                    <td><a class="btn btn-primary btn-sm" href="index.php?view_id=<?php echo $data['user_id']; ?>">View & Approve</a></td>
                                </tr>
                                <?php } } else { echo "<tr><td colspan='5' class='text-center'>No users pending approval.</td></tr>"; } ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- All Users List -->
                <div class="card">
                    <div class="card-header"><h5 class="card-title">All Client List</h5></div>
                    <div class="card-datatable table-responsive">
                        <table class="datatables-products table">
                            <thead class="border-top"><tr><th>ID</th><th>Client Name</th><th>Number</th><th>Gender</th><th>Status</th><th>Actions</th></tr></thead>
                            <tbody>
                                <?php 
                                $desql_all = mysqli_query($conn, "SELECT * FROM tbl_user ORDER BY user_id DESC");
                                foreach($desql_all as $data){ ?>
                                <tr>
                                    <td><?php echo $data['user_id']; ?></td>
                                    <td><?php echo htmlspecialchars($data['user_name']); ?></td>
                                    <td><?php echo htmlspecialchars($data['user_phone']); ?></td>
                                    <td><?php echo htmlspecialchars($data['user_gender']); ?></td>
                                    <td>
                                        <?php
                                            if ($data['user_status'] == '1') echo '<span class="badge bg-label-success">Approved</span>';
                                            elseif ($data['user_status'] == '2') echo '<span class="badge bg-label-danger">Rejected</span>';
                                            else echo '<span class="badge bg-label-warning">Pending</span>';
                                        ?>
                                    </td>
                                    <td>
                                        <a class="btn btn-info btn-sm" href="index.php?view_id=<?php echo $data['user_id']; ?>">View Details</a>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php
            } // End of the main if/else block for modes
            ?>
        </div>
        <!-- / Content -->
        <?php include "inc/footer.php"; ?>
      </div>
      <!-- / Content wrapper -->
    </div>
    <!-- / Layout page -->
  </div>
</div>
<!-- / Layout wrapper -->
</body>
</html>